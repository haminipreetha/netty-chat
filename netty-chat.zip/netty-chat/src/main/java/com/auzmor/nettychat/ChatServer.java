/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.auzmor.nettychat;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;

/**
 *
 * @author elcot
 */
public class ChatServer {
    
    public static void main(String arg[]) throws Exception{
        new ChatServer(8000).run();
    }
private final int port;
    private ChatServer(int port) {
        this.port=port;
    }

    public void run() throws Exception {
        System.out.println("ChatServer-run");
        EventLoopGroup bossGroup=new NioEventLoopGroup();
        EventLoopGroup workerGroup=new NioEventLoopGroup();
        try{
            ServerBootstrap  bootstrap=new ServerBootstrap()
                    .group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ChatServerInitializer());
            
            bootstrap.bind(port).sync().channel().closeFuture().sync();
           
        }
        
        finally{
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
               // System.out.println("===shutdownGracefully====");               
        }
       
     
    }
    
}
