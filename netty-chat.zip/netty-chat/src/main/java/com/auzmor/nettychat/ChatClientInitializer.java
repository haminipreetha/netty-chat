/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.auzmor.nettychat;

import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.Delimiters;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;

/**
 *
 * @author elcot
 */
class ChatClientInitializer extends ChannelInitializer<SocketChannel> {

    public ChatClientInitializer() {
    }

    @Override
    protected void initChannel(SocketChannel c) throws Exception {
        ChannelPipeline channelPipeline=c.pipeline();
         System.out.println("ChatClientInitializer - initChannel - addingPipeline ");
        channelPipeline.addLast("framer",new DelimiterBasedFrameDecoder(8192,Delimiters.lineDelimiter()));
        channelPipeline.addLast("decoder",new StringDecoder());
        channelPipeline.addLast("encoder",new StringEncoder());
        
        channelPipeline.addLast("handler",new ChatClientHandler());
 
        {
    }
    }
    
}
