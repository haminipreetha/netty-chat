/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.auzmor.nettychat;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundMessageHandlerAdapter;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;

/**
 *
 * @author elcot
 */
class ChatServerHandler extends ChannelInboundMessageHandlerAdapter<String>
{ 

    public static final ChannelGroup channels=new DefaultChannelGroup();
    
    public ChatServerHandler() {
        
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
Channel incoming=ctx.channel();
            for(Channel channel: channels){
                 channel.write("[SERVER]"+incoming.remoteAddress()+ " has left \n");
 
            }
            
            channels.remove(ctx.channel());
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        Channel incoming=ctx.channel();
            for(Channel channel: channels){
                 channel.write("[SERVER]"+incoming.remoteAddress()+ " has joined \n");
 
            }
            
            channels.add(ctx.channel());
        
    }

    public void messageReceived(ChannelHandlerContext chc, String message) throws Exception {
        Channel incoming=chc.channel();
    for(Channel channel: channels){
       
       if(channel != incoming){
            channel.write("["+incoming.remoteAddress()+"]"+"Server Says : "+message+"\n");
       }
    }
    }

        }
  