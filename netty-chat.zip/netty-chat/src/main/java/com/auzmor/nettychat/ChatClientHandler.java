/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.auzmor.nettychat;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundMessageHandlerAdapter;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author elcot
 */
class ChatClientHandler extends ChannelInboundMessageHandlerAdapter<String> {

   
   // public void messageReceived(ChannelHandlerContext chc, String t) throws Exception
    
   // {
        
       // System.out.println("ChatClientHandler - messageReceived - String ");
     //   System.out.println(t);
   // }

    public void messageReceived(ChannelHandlerContext chc, ByteBuf t) throws Exception
    
    {
 System.out.println("ChatClientHandler - messageReceived - ByteBuf ");
 System.out.println(t);
    }

    public void messageReceived(ChannelHandlerContext chc, String t) throws Exception {
        try{
            
        
         System.out.println("ChatClientHandler - messageReceived - Object ");
       System.out.println(t);
String[] parts = t.split("\\]"); // String array, each element is text between dots

String valueEntered = parts[1]; 
      //    String v= "{\n    \"name\": \"Garima\",\n \"surname\": \"Joshi\",\n \"phone\": 9832734651}";
        if(t!=null && !t.isEmpty() &&!t.contains("has")){
             JSONParser parser = new JSONParser();
   JSONObject json = (JSONObject) parser.parse(valueEntered);
   
    //  JSONObject v1 = (JSONObject) parser.parse(v);

            System.out.println(json);
            }}
        catch(Exception ex){
            //json parser error
        }

        
       
    

        
    }

   
}
