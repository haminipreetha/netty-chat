/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.auzmor.nettychat;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.Delimiters;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;

/**
 *
 * @author elcot
 */
class ChatServerInitializer extends ChannelInitializer<SocketChannel> {

    public ChatServerInitializer() {
    }

    @Override
    protected void initChannel(SocketChannel c) throws Exception {
        ChannelPipeline channelPipeline=c.pipeline();
        System.out.println("ChatServerInitializer-initChannel");
        channelPipeline.addLast("framer",new DelimiterBasedFrameDecoder(8192,Delimiters.lineDelimiter()));
        channelPipeline.addLast("decoder",new StringDecoder());
        channelPipeline.addLast("encoder",new StringEncoder());
        
        channelPipeline.addLast("handler",new ChatServerHandler());
 
        {
    }
    }
    
}

    

