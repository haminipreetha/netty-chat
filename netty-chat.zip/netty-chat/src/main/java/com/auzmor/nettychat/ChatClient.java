/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.auzmor.nettychat;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.channel.Channel;
import io.netty.util.CharsetUtil;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.json.simple.JSONObject;

/**
 *
 * @author elcot
 */
public class ChatClient {

    public static void main(String args[]) {
        new ChatClient("localhost", 8000).run();
    }
    private final String host;
    private final int port;

    private ChatClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void run() {
       
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap bootstrap = new Bootstrap()
                    .group(group).channel(NioSocketChannel.class)
                    .handler(new ChatClientInitializer());
            Channel channel = bootstrap
                    .connect(host, port).sync().channel();
          //   Channel channel1 = bootstrap
                //    .connect(host, port).sync().channel();
           
          BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            while (true) {
              //  String message;
               // JSONObject json = new JSONObject();

               // json.put("test1", "value1");

              //  JSONObject jsonObj = new JSONObject();

               // jsonObj.put("id", 0);
              //  jsonObj.put("name", "testName");
              //  json.put("test2", jsonObj);

             //message = json.toString();
      //       //System.out.println(message);
                System.out.println("Client - Please give me the json to send the Server ");
                
            String content=    br.readLine();
               channel.write(content + "\r\n");
               // System.out.println("channel writing my own typed content");
            
              //  System.out.println("channel writing my json and let see what my json has ...");

              //  System.out.println("this is my json "+json);
           //     channel1.write(json);

               //    channel.write("sysout == i am writing from client======>");
              //  channel.write("Json message in String "+message);
                
                //ByteBuf buffer = Unpooled.copiedBuffer(message, CharsetUtil.UTF_8);
                                          }
        } catch (Exception e) {
        } finally {
            group.shutdownGracefully();
        }
    }
}